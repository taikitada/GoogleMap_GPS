package Hello::ConfigLoader;
use strict;
use warnings;
use parent 'Amon2::ConfigLoader';
1;
