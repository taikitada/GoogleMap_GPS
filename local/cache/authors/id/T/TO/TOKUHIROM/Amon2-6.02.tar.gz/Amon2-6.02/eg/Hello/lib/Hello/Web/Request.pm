package Hello::Web::Request;
use strict;
use parent qw/Amon2::Web::Request/;
1;
