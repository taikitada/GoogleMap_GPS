package DeepNamespace::Config;
use Amon2::Config;
1;
