package Extended::Web::Request;
use strict;
use warnings;
use base qw/Amon2::Web::Request/;

1;
