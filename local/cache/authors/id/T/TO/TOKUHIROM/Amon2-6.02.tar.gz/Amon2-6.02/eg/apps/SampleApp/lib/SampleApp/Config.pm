package SampleApp::Config;
use Amon2::Config;
1;
